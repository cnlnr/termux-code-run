import inotify.adapters

def monitor_file_save_events():
    # 初始化 inotify 监控器
    i = inotify.adapters.Inotify()
    
    # 设置要监控的路径（请替换为你的实际路径）
    watch_path = '/storage/emulated/obb/代码运行'
    
    # 只添加 IN_CLOSE_WRITE 事件监控
    i.add_watch(watch_path, inotify.constants.IN_CLOSE_WRITE)
    
    print(f"开始监控 {watch_path} 的文件保存完成事件...")
    print("等待文件保存操作...")
    
    try:
        # 事件处理循环
        for event in i.event_gen():
            if event is not None:
                # 解析事件信息
                (_, event_types, path, filename) = event
                
                # 只处理 IN_CLOSE_WRITE 事件
                if 'IN_CLOSE_WRITE' in event_types:
                    filepath = f"{path}/{filename}"
                    print(f"文件已确认保存完成！ → {filepath}")
                    print("=" * 50)
                    
    except KeyboardInterrupt:
        print("\n监控已停止")

if __name__ == '__main__':
    monitor_file_save_events()